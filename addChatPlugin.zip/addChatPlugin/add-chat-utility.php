<?php
/**
 * Plugin Name: AddChat Utility
 * Description: AddChat Functionality to your webiste fast and efficient
 * Author: Mr Deepak
 * Author URI: https://www.linkedin.com/in/deepak-singh-8136a8b2/
 * Version: 1.0.0
 * Text Domain: add-chat-utility
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

class SimpleContactForm
{
    public function __construct()
    {
        // Hook into actions
        add_action('wp_enqueue_scripts', array($this, 'my_custom_plugin_enqueue_scripts'));
        add_action('admin_menu', array($this, 'my_plugin_menu'));
        add_action('admin_init', array($this, 'my_plugin_settings'));
    }

    // Enqueue FontAwesome and chat client JS
    public function my_custom_plugin_enqueue_scripts()
    {
        wp_enqueue_style('font-awesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css');
        wp_register_script('setup-script', plugin_dir_url(__FILE__) . 'js/setup.js', array('jquery'), null, true);
    
        $current_user = wp_get_current_user();
    
        $user_data = array(
            'isLoggedIn' => is_user_logged_in()? 'true' : 'false',
            'username'   => is_user_logged_in() ? $current_user->user_login : '',
            'email'      => is_user_logged_in() ? $current_user->user_email : '',
        );
    
        // Get the version from the plugin settings
        $version = get_option('my_plugin_version', 'beta'); // Default to 'beta' if no version is set
    
        wp_localize_script('setup-script', 'myPluginData', array(
            'apiKeyValue' => get_option('my_plugin_option', ''),  
            'appNameValue' => get_option('my_plugin_app_name', ''),  
            'chatBoxThemeColor' => get_option('my_plugin_header_theme_color', ''), 
            'version' => $version, // Pass the version to JavaScript
            'userData' => $user_data
        ));
    
        wp_enqueue_script('setup-script');
    
        // Use the dynamically retrieved version in the URL
        $addchat_client_url = "https://cdn.jsdelivr.net/gh/magicchat-core/dev-ssc-client-cdns@$version/bundle.js";
        
        wp_enqueue_script('addchat-client', $addchat_client_url, array(), null, true);
    
        $inline_script = "
            document.addEventListener('DOMContentLoaded', function () {
                console.log('User data from PHP:', myPluginData.userData);
                console.log('Plugin Version:', myPluginData.version); // Log the version
    
                if (myPluginData.userData.isLoggedIn ==='true' && myPluginData.userData.username) {
                    window.magicchat_io.initialize({ 'uid': myPluginData.userData.username });
                } 
            });
    
            function openChat() {
                alert('Chat button clicked!');
            }
        ";
        wp_add_inline_script('addchat-client', $inline_script);
    }
    

    public function my_plugin_menu()
    {
        add_menu_page('AddChat Settings', 'AddChat Settings', 'manage_options', 'setup', array($this, 'my_plugin_settings_page'));
    }

    public function my_plugin_settings_page()
    {
        ?>
        <div class="wrap">
            <h1>AddChat Settings</h1>
            <form method="post" action="options.php">
                <?php
                settings_fields('my_plugin_options_group');
                do_settings_sections('setup');
                submit_button();
                ?>
            </form>
        </div>
        <?php
    }

    public function my_plugin_settings()
    {
        register_setting('my_plugin_options_group', 'my_plugin_option');
        register_setting('my_plugin_options_group', 'my_plugin_app_name');
        register_setting('my_plugin_options_group', 'my_plugin_header_theme_color');
        register_setting('my_plugin_options_group', 'my_plugin_version'); // Register the new field
    
        add_settings_section('my_plugin_main_section', 'Chat App Credentials', array($this, 'my_plugin_section_callback'), 'setup');
    
        add_settings_field('my_plugin_option', 'API Key', array($this, 'my_plugin_option_callback'), 'setup', 'my_plugin_main_section');
        add_settings_field('my_plugin_app_name', 'App Name', array($this, 'my_plugin_app_name_callback'), 'setup', 'my_plugin_main_section');
        add_settings_field('my_plugin_header_theme_color', 'Theme Color', array($this, 'my_plugin_header_theme_color_callback'), 'setup', 'my_plugin_main_section');
        add_settings_field('my_plugin_version', 'Version', array($this, 'my_plugin_version_callback'), 'setup', 'my_plugin_main_section'); // Add the new field
    }


    public function my_plugin_section_callback()
    {
        echo 'Enter your settings below:';
    }

    // Add the callback for the new field
    public function my_plugin_version_callback()
    {
        ?>
        <input type="text" name="my_plugin_version" value="<?php echo get_option('my_plugin_version'); ?>" placeholder="Enter version" />
        <?php
    }

    public function my_plugin_option_callback()
    {
        ?>
        <input type="text" name="my_plugin_option" value="<?php echo get_option('my_plugin_option'); ?>" />
        <?php
    }

    public function my_plugin_app_name_callback()
    {
        ?>
        <input type="text" name="my_plugin_app_name" value="<?php echo get_option('my_plugin_app_name'); ?>" />
        <?php
    }

    public function my_plugin_header_theme_color_callback()
    {
        ?>
        <!-- <input type="text" name="my_plugin_header_theme_color" value="<?php echo get_option('my_plugin_header_theme_color'); ?>" class="color-picker" data-default-color="#000000" /> -->
        <textarea name="my_plugin_header_theme_color" rows="10" cols="50"><?php echo esc_textarea(get_option('my_plugin_header_theme_color')); ?></textarea>
 
        <?php
    }

}

new SimpleContactForm();