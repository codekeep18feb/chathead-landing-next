(function ($) {
  document.addEventListener("DOMContentLoaded", function () {
    console.log("arewerehever", myPluginData, typeof myPluginData);
    // Access the localized data in JavaScript
    if (myPluginData.userData.isLoggedIn === "false") {
      console.log("User is logged out.");

      window.magicchat_io.logout(); // to perform clean up correct way

      var apiKeyValue = myPluginData.apiKeyValue;
      var appNameValue = myPluginData.appNameValue;

      // Check if apiKeyValue is provided
      if (!apiKeyValue) {
        console.error("`API Key` is missing. Please provide a valid API Key.");
      }

      if (!appNameValue) {
        console.error("`App Name` is missing. Please provide a valid API Key.");
      }

      console.log(
        "sdfsadfasdfmyPluginData.chatBoxThemeColor",
        myPluginData.chatBoxThemeColor
      );

      window.magicchat_io.setUp(
        appNameValue,
        apiKeyValue,
        myPluginData.chatBoxThemeColor
      );
    }
  });
})(jQuery);
